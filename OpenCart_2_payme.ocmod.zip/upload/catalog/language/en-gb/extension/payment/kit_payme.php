<?php
// Text
$_['text_title'] = '<img style="width: 100px;" src="/catalog/view/theme/default/image/kit_payme.png" alt="Kit Payme" title="Kit Payme" style="border: 1px solid #EEEEEE;" />';
$_['text_status'] = 'status';
$_['text_title_order'] = 'Заявка на товар';